/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

java.util.Date; 

public class BettingApp {

    public BettingApp (string userName, string passWord, string firstName, string lastName, LocalDate birthDay){
    userName = Name;
    passWord = Pass;
    firstName = name;
    lastName = Name;
    birthDay = 11.04.1996;
}

    public void User() {
    string userName;
    string passWord;
    string firstName;
    string lastName;
    LocalDate birthDay; 
}

    Public void Bet() {
    string userName;
    string category;
    int bettingTable;
    double amount;
    double odd;
    LocalDate timePlaced;
}

    public void BettingTable() {
    int tableID;
    int potSize;
    int numParticipants;
    string category;
    string betType;
    Bet betsPlaced;
    LocalDate cutOff;
    LocalDate createdOn;
    double minimumBet;
}

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
